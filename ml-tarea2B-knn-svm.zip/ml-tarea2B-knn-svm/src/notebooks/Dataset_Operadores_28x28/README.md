Colección de diferentes imágenes
correspondientes a cada operador
requerido para la Tarea #2 de ML

Dimensiones: 28x28
