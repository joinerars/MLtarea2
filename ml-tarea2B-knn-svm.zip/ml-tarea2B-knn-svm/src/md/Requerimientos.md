# Requerimientos mínimos

| Requerimiento | Descripción |
|:------:| :-----------:|
| Entrada de valores  | Exactamente la sección inicial de `canvas` sin los tabs de despliegue para entender los datos |
| Desplegar el resultado de las operaciones  | De alguna manera debemos entender la salida de la operación. Se debe entender cómo ejecutar y cuándo la operación. |
| Uso de modelos de ML  | Como mínimo se deben usar 2 modelos uno para números y el otro para operandos. Si quieren comparar rendimiento de modelos pueden colocar más de una sola salida sin embargo solo una es requerimiento |
